<!--Observa cÃģmo se genera una cabecera de formulario distinta segÃšn se vaya a usar el formulario para crear o para modificar un producto. AsÃ­mismo, fÃ­jate en cÃģmo se rellenan los atributos value de los campos del formulario con los datos actuales del producto (en caso de que existan).-->



<?php $__env->startSection("title", "Pelicula"); ?>

<?php $__env->startSection("header", "Peliculas"); ?>

<?php $__env->startSection("content"); ?>
    <a href="<?php echo e(route('movie.list')); ?>"><h1>PELICULAS ONLINE</h1></a><br>
    <a href="<?php echo e(route('ultimas-novedades')); ?>"><button>Últimas novedades</button></a> 
    <a href="<?php echo e(route('proximos-estrenos')); ?>"><button>Próximos estrenos</button></a><br><br><br><br><br><br>

    <?php if(isset($movie)): ?>
        <form action="<?php echo e(route('movie.update', ['movie' => $movie->id])); ?>" method="POST">
        <?php echo method_field("PUT"); ?>
    <?php else: ?>
    <?php endif; ?>
        <?php echo csrf_field(); ?>
        <label class="titu" for="titulo">Titulo:</label><br>
        <input class="titu" type="text" name="name" value=""><br><br>

        <label class="titu" for="director">Director:</label><br>
        <input class="titu" type="text" name="director" value=""><br><br>

        Genero: <br>
        <div class="button-container">
            <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('peliculasporgenero', ['genre' => $genre->id])); ?>" class="genre-link">
                    <input class="buttonG" type="button" value="<?php echo e($genre->genre); ?>">
                </a>
                <?php if($loop->iteration % 3 == 0): ?>
                    <br>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
    <h1>CATALOGO DE PELICULAS</h1><br><br>
    <div class="link-container">
    <?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('peli', ['id' => $movie->id])); ?>">
            <img src="<?php echo e(asset('images/'.$movie->image)); ?>" alt="" width="30%">
        </a>
        <?php if($loop->iteration % 3 == 0): ?>
            <br>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Desarrollo-web-en-entorno-servidor\Ev2 - OOP\Laravel\Sitio_Web_Laravel\resources\views/proximos-estrenos.blade.php ENDPATH**/ ?>