<html>

    <head>
       <title><?php echo $__env->yieldContent('title'); ?></title>
       <link rel="stylesheet" href="<?php echo e(asset('../public/css/estilo.css')); ?>">
    </head>
    <body>
        <header>
        </header>
        <?php $__env->startSection('sidebar'); ?>
        <section>
            <nav>
                <div class="container">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </nav>
            <main>
                <div class="content">
                    <?php echo $__env->yieldContent('contenido'); ?>
                </div>
            </main>
        </section>
        <footer></footer>
    </body>
</html><?php /**PATH D:\xampp\htdocs\Desarrollo-web-en-entorno-servidor\Ev2 - OOP\Laravel\Sitio_Web_Laravel\resources\views/master.blade.php ENDPATH**/ ?>