<!--Observa cÃģmo se genera una cabecera de formulario distinta segÃšn se vaya a usar el formulario para crear o para modificar un producto. AsÃ­mismo, fÃ­jate en cÃģmo se rellenan los atributos value de los campos del formulario con los datos actuales del producto (en caso de que existan).-->



<?php $__env->startSection("title", "Pelicula"); ?>

<?php $__env->startSection("header", "Peliculas"); ?>

<?php $__env->startSection("content"); ?>
    <a href="<?php echo e(route('movie.list')); ?>"><h1>PELICULAS ONLINE</h1></a><br>
    <a href="<?php echo e(route('ultimas-novedades')); ?>"><button>Últimas novedades</button></a> 
    <a href="<?php echo e(route('proximos-estrenos')); ?>"><button>Próximos estrenos</button></a><br><br><br><br><br><br>

    <?php if(isset($movie)): ?>
        <form action="" method="POST">
        <?php echo method_field("PUT"); ?>
    <?php else: ?>
    <?php endif; ?>
        <?php echo csrf_field(); ?>
        <label class="titu" for="titulo">Titulo:</label><br>
        <input class="titu" type="text" name="name" value=""><br><br>

        <label class="titu" for="director">Director:</label><br>
        <input class="titu" type="text" name="director" value=""><br><br>

        <label class="titu" for="titulo">Genero:</label><br>
        <div class="button-container">
            <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('peliculasporgenero', ['genre' => $genre->id])); ?>" class="genre-link">
                    <input class="buttonG" type="button" value="<?php echo e($genre->genre); ?>">
                </a>
                <?php if($loop->iteration % 3 == 0): ?>
                    <br>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
    <div class="peli">
        <h1><?php echo e($movie->title); ?></h1>
        <img src="<?php echo e(asset('images/'.$movie->image)); ?>" alt="" width="30%" class="imagen">
        <div class="datosPeli">
            <p class="lado"><strong>Director:</strong> <?php echo e($movie->Director->name); ?></p><br>
            <p class="lado"><strong>Actor:</strong> <?php echo e($movie->LeadActor->name); ?></p><br>
            <p class="lado"><strong>Guionistas:</strong>
            <?php $__currentLoopData = $movie->writers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $writer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($writer->name); ?></p><br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <p class="lado"><strong>Fecha de estreno:</strong> <?php echo e($movie->release_date); ?></p><br>
            <p class="lado"><strong>Duración:</strong><?php echo e($movie->duration); ?></p><br>
            <p class="lado"><strong>Genero:</strong> <?php echo e($movie->Genre->genre); ?></p><br>
        </div>
        <p class="sino"><strong>Sinopsis:</strong> <?php echo e($movie->synopsis); ?></p><br>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Desarrollo-web-en-entorno-servidor\Ev2 - OOP\Laravel\Sitio_Web_Laravel\resources\views/peli.blade.php ENDPATH**/ ?>