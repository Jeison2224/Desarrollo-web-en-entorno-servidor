<?php $__env->startSection('title', 'Pedidos por empleado'); ?>

<?php $__env->startSection('header', 'Pedidos por empleado'); ?>

<?php $__env->startSection('main_title', 'Producto solicitado'); ?>

<?php $__env->startSection('content'); ?>
    <p>Para: <?php echo e($product->supplier->contact->employee->name); ?> <?php echo e($product->supplier->contact->employee->surname); ?></p><br>
    <h2 class="centrado"><b><?php echo e($product->name); ?></b></h2>
    <ul>
        <li>Cantidad solicitada: <?php echo e($amount); ?></li>
        <li>Cantidad en stock: <?php echo e($product->stock); ?></li>
        <li>Proveedor: <?php echo e($product->supplier->name); ?></li>
        <li>Teléfono de contacto: <?php echo e($product->supplier->contact->phone_number); ?>

            (<?php echo e($product->supplier->contact->name); ?> <?php echo e($product->supplier->contact->surname); ?>)
        </li>
        <li>Empleado solicitante (ID): <?php echo e($employee->id); ?></li>
    </ul>

    <br><br>
    <form action = "<?php echo e(route('menu')); ?>" method="GET" class="centrado">
        <?php echo csrf_field(); ?>
        <input type="submit" value="MENÚ PRINCIPAL">
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JMedrano\Programas\Xampp\htdocs\Desarrollo-web-en-entorno-servidor\Ev2 - OOP\Laravel\examen_eva2\resources\views/order/resume.blade.php ENDPATH**/ ?>