<?php $__env->startSection('title', 'Gestión de empresa'); ?>

<?php $__env->startSection('header', 'Gestión de empresa'); ?>

<?php $__env->startSection('main_title', 'Registros de la base de datos'); ?>

<?php $__env->startSection('content'); ?>
    <table class="sinbordes">
        <tr>
            <td class="sinbordes mitad">
                <form action = "<?php echo e(route('product.index')); ?>" method="GET" class="centrado">
                    <?php echo csrf_field(); ?>
                    <input type="submit" value="Productos en stock" class="grande">
                </form>
            </td>
            <td class="sinbordes mitad">
                <form action = "<?php echo e(route('supplier.index')); ?>" method="GET" class="centrado">
                    <?php echo csrf_field(); ?>
                    <input type="submit" value="Proveedores" class="grande">
                </form>
            </td>
        </tr>
        <tr>
            <td class="sinbordes mitad">
                <form action = "<?php echo e(route('contact.index')); ?>" method="GET" class="centrado">
                    <?php echo csrf_field(); ?>
                    <input type="submit" value="Contactos" class="grande">
                </form>
            </td>
            <td class="sinbordes mitad">
                <form action = "<?php echo e(route('employee.index')); ?>" method="GET" class="centrado">
                    <?php echo csrf_field(); ?>
                    <input type="submit" value="Empleados" class="grande">
                </form>
            </td>
        </tr>
        <tr>
            <td class="sinbordes mitad">
                <form action = "<?php echo e(route('supplier.products')); ?>" method="GET" class="centrado">
                    <?php echo csrf_field(); ?>
                    <input type="submit" value="Productos por proveedor" class="grande">
                </form>
            </td>
            <td class="sinbordes mitad">

                <form action = "<?php echo e(route('order.form')); ?>" method="GET" class="centrado">
                    <?php echo csrf_field(); ?>
                    <input type="submit" value="Realizar un pedido pedido" class="grande">
                </form>
            </td>
        </tr>
        <tr>
            <td class="sinbordes"  colspan=2>
                <form action = "<?php echo e(route('order.all')); ?>" method="GET" class="centrado">
                    <?php echo csrf_field(); ?>
                    <input type="submit" value="Pedidos" class="grande">
                </form>
            </td>
        </tr>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JMedrano\Programas\Xampp\htdocs\Desarrollo-web-en-entorno-servidor\Ev2 - OOP\Laravel\examen_eva2\resources\views/index.blade.php ENDPATH**/ ?>