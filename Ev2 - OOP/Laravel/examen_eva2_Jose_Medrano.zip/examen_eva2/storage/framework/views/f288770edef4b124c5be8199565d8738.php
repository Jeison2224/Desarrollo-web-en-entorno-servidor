<?php $__env->startSection("title", "Administración de proveedores"); ?>

<?php $__env->startSection("header", "Administración de proveedores"); ?>

<?php $__env->startSection("main_title", "Listado de proveedores"); ?>

<?php $__env->startSection("content"); ?>
    <table class='sinbordes'>
        <tr>
            <th>Proveedor</th><th>Dirección</th><th>Ciudad</th><th>País</th><th class='sinbordes'></th><th class='sinbordes'></th>
        </tr>
    <?php $__currentLoopData = $supplierList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($supplier->name); ?></td>
            <td><?php echo e($supplier->address); ?></td>
            <td><?php echo e($supplier->city); ?></td>
            <td><?php echo e($supplier->country); ?></td>
            <td class='sinbordes centrado'>
                <a href="<?php echo e(route('supplier.edit', $supplier->id)); ?>">Modificar</a>
            </td>
            <td class='sinbordes'>
                <form action = "<?php echo e(route('supplier.destroy', $supplier->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field("DELETE"); ?>
                    <input type="submit" value="Borrar">
                </form>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table><br>
    <a href="<?php echo e(route('supplier.create')); ?>">Nuevo proveedor</a>

    <br><br>
    <form action = "<?php echo e(route('menu')); ?>" method="GET" class="centrado">
        <?php echo csrf_field(); ?>
        <input type="submit" value="MENÚ PRINCIPAL">
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JMedrano\Programas\Xampp\htdocs\Desarrollo-web-en-entorno-servidor\Ev2 - OOP\Laravel\examen_eva2\resources\views/supplier/all.blade.php ENDPATH**/ ?>